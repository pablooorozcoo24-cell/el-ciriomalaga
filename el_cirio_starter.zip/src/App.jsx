
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from "react-router-dom";
import { MapContainer, TileLayer, Polyline, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import cofradias from "./data/cofradias.json";

function Nav(){
  return (
    <nav className="bg-black text-white p-4 sticky top-0 z-10">
      <div className="max-w-5xl mx-auto flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-purple-300">El Cirio</Link>
        <div className="space-x-3">
          <Link to="/cofradias" className="px-3 py-1 rounded hover:bg-gray-800">Cofradías</Link>
          <Link to="/calendario" className="px-3 py-1 rounded hover:bg-gray-800">Calendario</Link>
          <Link to="/mapa" className="px-3 py-1 rounded hover:bg-gray-800">Mapa</Link>
          <Link to="/galeria" className="px-3 py-1 rounded hover:bg-gray-800">Galería</Link>
        </div>
      </div>
    </nav>
  );
}

function Home(){
  return (
    <div className="max-w-5xl mx-auto p-6 text-white">
      <h1 className="text-3xl font-extrabold mb-4">Bienvenido a El Cirio — Semana Santa Málaga</h1>
      <p className="mb-4 text-gray-300">Consulta horarios, recorridos y fichas oficiales de las hermandades de Málaga.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CardLink to="/cofradias" title="Cofradías">Lista completa de hermandades.</CardLink>
        <CardLink to="/calendario" title="Calendario">Procesiones por día y hora.</CardLink>
        <CardLink to="/mapa" title="Mapa">Recorridos interactivos.</CardLink>
        <CardLink to="/galeria" title="Galería">Fotos por hermandad.</CardLink>
      </div>
    </div>
  );
}

function CardLink({to, title, children}){
  return (
    <Link to={to} className="block p-4 bg-gray-900/40 rounded-lg border border-gray-800">
      <h3 className="font-semibold text-purple-200">{title}</h3>
      <p className="text-sm text-gray-300">{children}</p>
    </Link>
  );
}

function CofradiasList(){
  const navigate = useNavigate();
  return (
    <div className="max-w-5xl mx-auto p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">Cofradías</h2>
      <div className="space-y-4">
        {cofradias.map(c => (
          <div key={c.id} className="flex items-center bg-gray-900 p-3 rounded shadow">
            <img src={c.emblem || `/images/${c.id}.svg`} alt={c.name} className="w-16 h-16 object-cover rounded mr-4" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-100">{c.name} <span className="text-sm text-gray-400">({c.processionDay})</span></h3>
              <p className="text-sm text-gray-300">{c.description}</p>
              <div className="text-xs text-gray-500 mt-1">{c.time}</div>
            </div>
            <div>
              <button onClick={() => navigate(`/cofradias/${c.id}`)} className="px-3 py-1 rounded bg-purple-600 text-white">Ver</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CofradiaDetalle(){
  const { id } = useParams();
  const c = cofradias.find(x => x.id === id);
  if (!c) return <div className="p-6 text-white">Cofradía no encontrada.</div>;
  return (
    <div className="max-w-5xl mx-auto p-6 text-white">
      <div className="flex items-start gap-4">
        <img src={c.emblem || `/images/${c.id}.svg`} alt={c.name} className="w-28 h-28 object-cover rounded" />
        <div>
          <h2 className="text-2xl font-bold">{c.name}</h2>
          <div className="text-sm text-gray-400">{c.processionDay} · {c.time}</div>
          <p className="mt-3 text-gray-300">{c.description}</p>
          <div className="mt-3 space-y-1 text-sm text-gray-400">
            <div>Contacto: {c.contact?.email || '-'} · {c.contact?.phone || '-'}</div>
          </div>
        </div>
      </div>

      <h3 className="mt-6 font-semibold">Recorrido</h3>
      <div className="h-64 mt-2 rounded overflow-hidden shadow">
        {c.route && c.route.length > 0 ? (
          <MapContainer center={c.route[0]} zoom={15} style={{ height: "100%", width: "100%" }}>
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <Polyline positions={c.route} />
            <Marker position={c.route[0]}><Popup>Salida</Popup></Marker>
            <Marker position={c.route[c.route.length-1]}><Popup>Llegada</Popup></Marker>
          </MapContainer>
        ) : (
          <div className="p-4 text-gray-400">Recorrido no disponible.</div>
        )}
      </div>

      <h3 className="mt-6 font-semibold">Galería</h3>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
        {(c.gallery || []).map((g,i) => <img key={i} src={g} alt={`foto-${i}`} className="w-full h-28 object-cover rounded" />)}
      </div>
    </div>
  );
}

function Calendario(){
  const grouped = cofradias.reduce((acc,c) => { acc[c.processionDay]=acc[c.processionDay]||[]; acc[c.processionDay].push(c); return acc; }, {});
  return (
    <div className="max-w-5xl mx-auto p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">Calendario</h2>
      {Object.keys(grouped).map(day => (
        <div key={day} className="mb-4">
          <h3 className="font-semibold text-purple-200">{day}</h3>
          <ul className="mt-2">
            {grouped[day].map(c => <li key={c.id} className="py-2 border-b border-gray-800">{c.time} — <Link to={`/cofradias/${c.id}`} className="text-purple-300">{c.name}</Link></li>)}
          </ul>
        </div>
      ))}
    </div>
  );
}

function Mapa(){
  const allRoutes = cofradias.flatMap(c => c.route || []);
  const center = allRoutes.length ? allRoutes[0] : [36.7213028, -4.4216366];
  return (
    <div className="max-w-6xl mx-auto p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">Mapa de recorridos</h2>
      <div className="h-[60vh] rounded overflow-hidden shadow">
        <MapContainer center={center} zoom={13} style={{ height: "100%", width: "100%" }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          {cofradias.map(c => c.route && <Polyline key={c.id} positions={c.route} />)}
        </MapContainer>
      </div>
    </div>
  );
}

function Galeria(){
  const allImages = cofradias.flatMap(c => (c.gallery||[]).map(g => ({src:g, title:c.name})));
  return (
    <div className="max-w-5xl mx-auto p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">Galería</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {allImages.map((img,i) => (
          <div key={i} className="overflow-hidden rounded shadow">
            <img src={img.src} alt={img.title} className="w-full h-40 object-cover" />
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App(){
  return (
    <Router>
      <div className="min-h-screen bg-black">
        <Nav />
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/cofradias" element={<CofradiasList/>} />
          <Route path="/cofradias/:id" element={<CofradiaDetalle/>} />
          <Route path="/calendario" element={<Calendario/>} />
          <Route path="/mapa" element={<Mapa/>} />
          <Route path="/galeria" element={<Galeria/>} />
        </Routes>
      </div>
    </Router>
  );
}
