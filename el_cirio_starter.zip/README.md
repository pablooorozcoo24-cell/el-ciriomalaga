El Cirio — Starter (React + Tailwind-ready)
===========================================

Estructura mínima para desplegar rápido en Replit/Netlify/Vercel.

Cómo desplegar en Replit (muy sencillo):
1. Crea una cuenta en Replit (si no tienes).
2. En Replit > Create > Import from ZIP > sube este archivo el_cirio_starter.zip.
3. Espera a que instale y pulsa "Run". Si te pide comando, usa: npm run dev
4. Abre el enlace público que Replit proporciona.

Cómo desplegar en Netlify (drag-and-drop):
1. Descomprime el ZIP en tu PC.
2. Arrastra la carpeta 'el-cirio-starter' comprimida al área 'Deploy site' de Netlify.
3. En Netlify, configura build command: npm run build, publish directory: dist

IMPORTANTE SOBRE DATOS E IMÁGENES:
- Este paquete incluye archivos de muestra y placeholders para las imágenes.
- En la carpeta /public/images encontrarás SVGs de ejemplo. Sustitúyelos por las fotos oficiales cuando las tengas.
- Para añadir los itinerarios oficiales (Agrupación de Cofradías), descarga el PDF oficial y copia los datos en /src/data/cofradias.json

Si quieres, te guío paso a paso para desplegar y yo te explico cada pantalla.
